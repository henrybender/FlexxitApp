//
//  Post.swift
//  SocialMediaPg
//
//  Created by Henry Bender on 11/29/18.
//  Copyright © 2018 Henry Bender. All rights reserved.
//

import Foundation


class Post {
    
    var likes: Int
    var id: Int
    var text: String
    var workout: String
    var nickname: String
    
    
    init(likes: Int, id: Int, text: String, workout: String, nickname: String) {
        self.likes = likes
        self.id = id
        self.text = text
        self.workout = workout
        self.nickname = nickname
    }
    
    
}
