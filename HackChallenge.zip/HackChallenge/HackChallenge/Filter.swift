//
//  Filter.swift
//  MusicFit
//
//  Created by Emily Reynolds on 11/27/18.
//  Copyright © 2018 Emily Reynolds. All rights reserved.
//
import Foundation

class Filter {
    var type: String!
    
    init(type: String) {
        self.type = type
    }
}
