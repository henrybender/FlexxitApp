//
//  PostTableViewCell.swift
//  SocialMediaPg
//
//  Created by Henry Bender on 11/29/18.
//  Copyright © 2018 Henry Bender. All rights reserved.
//

import UIKit

class PostTableViewCell: UITableViewCell {
    
    
    var likes: UILabel!
    var id: UILabel!
    var postText: UITextView!
    var workout: UILabel!
    var nickname: UILabel!
    var heartImageView: UIImageView!
    var justDid: UILabel!
    
    let heartImageWidth: CGFloat = 25
    let heartImageHeight: CGFloat = 25
    
    let padding: CGFloat = 10
    let labelHeight: CGFloat = 20
    
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        likes = UILabel()
        likes.translatesAutoresizingMaskIntoConstraints = false
        likes.font = UIFont.boldSystemFont(ofSize: 12)
        
        heartImageView = UIImageView(image: #imageLiteral(resourceName: "heart"))
        heartImageView.translatesAutoresizingMaskIntoConstraints = false
        heartImageView.contentMode = .scaleAspectFit
        heartImageView.isHidden = false
        
        id = UILabel()
        id.translatesAutoresizingMaskIntoConstraints = false
        id.font = UIFont.systemFont(ofSize: 14)
        
        justDid = UILabel()
        justDid.translatesAutoresizingMaskIntoConstraints = false
        justDid.font = UIFont.systemFont(ofSize: 14)
        
        postText = UITextView()
        postText.translatesAutoresizingMaskIntoConstraints = false
        postText.font = UIFont.systemFont(ofSize: 14)
        
        workout = UILabel()
        workout.translatesAutoresizingMaskIntoConstraints = false
        workout.font = UIFont.systemFont(ofSize: 14)
        
        nickname = UILabel()
        nickname.translatesAutoresizingMaskIntoConstraints = false
        nickname.font = UIFont.boldSystemFont(ofSize: 16)
        
        
        contentView.addSubview(likes)
        contentView.addSubview(id)
        contentView.addSubview(postText)
        contentView.addSubview(workout)
        contentView.addSubview(nickname)
        contentView.addSubview(heartImageView)
        
        
    }
    
    override func updateConstraints() {
        NSLayoutConstraint.activate([
            nickname.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            nickname.topAnchor.constraint(equalTo: contentView.topAnchor, constant: padding),
            nickname.heightAnchor.constraint(equalToConstant: labelHeight)
            ])
        
        NSLayoutConstraint.activate([
            workout.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            workout.topAnchor.constraint(equalTo: nickname.bottomAnchor),
            workout.heightAnchor.constraint(equalToConstant: labelHeight)
            ])
        
        NSLayoutConstraint.activate([
            postText.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: padding),
            postText.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            postText.topAnchor.constraint(equalTo: workout.bottomAnchor),
            postText.heightAnchor.constraint(equalToConstant: 50)
            ])
        
        NSLayoutConstraint.activate([
            likes.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            likes.topAnchor.constraint(equalTo: heartImageView.bottomAnchor),
            likes.heightAnchor.constraint(equalToConstant: 15),
            likes.widthAnchor.constraint(equalToConstant: 15)
            ])
        
        NSLayoutConstraint.activate([
            heartImageView.trailingAnchor.constraint(equalTo: contentView.trailingAnchor, constant: -padding),
            heartImageView.centerYAnchor.constraint(equalTo: contentView.centerYAnchor, constant: -padding),
            heartImageView.heightAnchor.constraint(equalToConstant: heartImageHeight),
            heartImageView.widthAnchor.constraint(equalToConstant: heartImageWidth)
            ])
        
        super.updateConstraints()
    }
    
    func configure(for post: Post) {
        nickname.text = post.nickname
        workout.text = post.workout
        likes.text = String(post.likes)
        postText.text = post.text
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

