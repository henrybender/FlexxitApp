//
//  WorkoutViewController.swift
//  MusicFit
//
//  Created by Emily Reynolds on 11/29/18.
//  Copyright © 2018 Emily Reynolds. All rights reserved.
//
import UIKit

protocol ViewWorkoutDelegate: class {
    func workoutInfo(imageName: String, name: String, type: [String], index: Int)
}

protocol PushField: class {
    func pushField(workoutName: String, workoutImg: String)
}


class WorkoutViewController: UIViewController {
    
    var viewLabel = UILabel()
    var workoutImage = UIImageView()
    var workoutImageName: String = ""
    var workoutDescription = UITextView()
    var playButton: UIButton!
    var postButton: UIButton!
    
    weak var postDelegate: PostField?
    weak var workoutZoomDelegate: WorkoutZoomDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        
        viewLabel.translatesAutoresizingMaskIntoConstraints = false
        viewLabel.backgroundColor = .white
        viewLabel.textAlignment = .center
        viewLabel.font = UIFont.systemFont(ofSize: 24, weight: .bold)
        view.addSubview(viewLabel)
        
        workoutImage.translatesAutoresizingMaskIntoConstraints = false
        workoutImage.contentMode = .scaleAspectFit
        view.addSubview(workoutImage)
        
        workoutDescription.translatesAutoresizingMaskIntoConstraints = false
        workoutDescription.backgroundColor = .white
        workoutDescription.textAlignment = .left
        view.addSubview(workoutDescription)
        
        playButton = UIButton()
        playButton.translatesAutoresizingMaskIntoConstraints = false
        playButton.setTitle("Play", for: .normal)
        playButton.backgroundColor = UIColor(red: 1, green: 153/255, blue: 102/255, alpha: 0.65)
        playButton.setTitleColor(.white, for: .normal)
        view.addSubview(playButton)
        
        playButton.addTarget(self, action: #selector(playSong), for: .touchUpInside)
        
        postButton = UIButton()
        postButton.translatesAutoresizingMaskIntoConstraints = false
        postButton.setTitle("Share", for: .normal)
        postButton.backgroundColor = UIColor(red: 1, green: 153/255, blue: 102/255, alpha: 0.65)
        postButton.setTitleColor(.white, for: .normal)
        view.addSubview(postButton)
        
        postButton.addTarget(self, action: #selector(sharePost), for: .touchUpInside)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            viewLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0),
            viewLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            viewLabel.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            workoutImage.topAnchor.constraint(equalTo: viewLabel.bottomAnchor, constant: 10),
            workoutImage.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            workoutImage.heightAnchor.constraint(equalToConstant: 260)
            ])
        
        NSLayoutConstraint.activate([
            workoutDescription.topAnchor.constraint(equalTo: workoutImage.bottomAnchor, constant: 10),
            workoutDescription.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            workoutDescription.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            workoutDescription.heightAnchor.constraint(equalToConstant: 160)
            ])
        
        NSLayoutConstraint.activate([
            playButton.topAnchor.constraint(equalTo: workoutDescription.bottomAnchor, constant: 30),
            playButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            playButton.heightAnchor.constraint(equalToConstant: 30),
            playButton.widthAnchor.constraint(equalToConstant: 70)
            ])
        
        NSLayoutConstraint.activate([
            postButton.topAnchor.constraint(equalTo: playButton.bottomAnchor, constant: 30),
            postButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            postButton.heightAnchor.constraint(equalToConstant: 30),
            postButton.widthAnchor.constraint(equalToConstant: 70)
            ])
    }
    
    @objc func playSong() {
        return
    }
    
    @objc func sharePost() {
        let postViewController = PostViewController()
        postViewController.pushDelegate = self
        postDelegate?.postField(workoutName: viewLabel.text!, workoutImg: workoutImageName)
        present(postViewController, animated: true, completion: nil)
    }
    
    @objc func backAction() {
        dismiss(animated: true, completion: nil)
    }
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension WorkoutViewController: ViewWorkoutDelegate {
    func workoutInfo(imageName: String, name: String, type: [String], index: Int) {
        viewLabel.text = name
        workoutImage.image = UIImage(named: imageName)
        workoutImageName = imageName
        workoutDescription.text = type.joined(separator: ", ")
    }
}

extension WorkoutViewController: PushField {
    func pushField(workoutName: String, workoutImg: String) {
        viewLabel.text = workoutName
        workoutImage.image = UIImage(named: workoutImg)
    }
}

