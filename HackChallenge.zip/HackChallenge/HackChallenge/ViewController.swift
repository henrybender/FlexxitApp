//
//  ViewController.swift
//  MusicFit
//
//  Created by Emily Reynolds on 11/27/18.
//  Copyright © 2018 Emily Reynolds. All rights reserved.
//
import UIKit

protocol WorkoutZoomDelegate: class {
    func seeWorkout(imageName: String, name: String, type: [String], index: Int)
}

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    var workoutCollection: UICollectionView!
    var workouts: [Workout]!
    var filterCollection: UICollectionView!
    var filters: [Filter]!
    var ogWorkouts: [Workout]!
    
    let workoutCellReuseIdentifier = "restaurantCellReuseIdentifier"
    let filterReuseIdentifier = "filterReuseIdentifier"
    let Rpadding: CGFloat = 7.0
    let Fpadding: CGFloat = 2.0
    
    weak var viewWorkoutDelegate: ViewWorkoutDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Workouts"
        view.backgroundColor = .white
        
        let jumpingJacks = Workout(imageName: "jumpingjacks", name: "Jumping Jacks", type: ["Cardio"])
        let sideLegRaises = Workout(imageName: "sidelegraises", name: "Side Leg Raises", type: ["Legs"])
        let kneeToElbows = Workout(imageName: "knee-to-elbows", name: "Knee-to-Elbows", type: ["Abs"])
        let lungePunches = Workout(imageName: "lungepunches", name: "Lunge Punches", type: ["Arms", "Legs"])
        let squatSideKick = Workout(imageName: "squat+sidekick", name: "Squat + Side Kick", type: ["Legs", "Butt"])
        let squatFrontKick = Workout(imageName: "squat+frontkick", name: "Squat + Front Kick", type: ["Legs", "Butt"])
        let legRaises = Workout(imageName: "legraises", name: "Leg Raises", type: ["Legs"])
        let squatHold = Workout(imageName: "squathold", name: "Squat Hold", type: ["Butt"])
        let marchSteps = Workout(imageName: "marchsteps", name: "March Steps", type: ["Cardio"])
        let calfRaises = Workout(imageName: "calfraises", name: "Calf Raises", type:    ["Legs"])
        let lunges = Workout(imageName: "lunges", name: "Lunges", type: ["Legs"])
        let shoulderTaps = Workout(imageName: "shouldertaps", name: "Shoulder Taps", type: ["Abs"])
        let plankRotations = Workout(imageName: "plankrotations", name: "Plank Rotations", type: ["Abs"])
        let highCrunches = Workout(imageName: "highcrunches", name: "High Crunches", type: ["Abs"])
        let sideJacks = Workout(imageName: "sidejacks", name: "Side Jacks", type: ["Abs"])
        let bridges = Workout(imageName: "bridges", name: "Bridges", type: ["Abs"])
        let hollowHold = Workout(imageName: "hollowhold", name: "Hollow Hold", type: ["Abs"])
        let crunches = Workout(imageName: "crunches", name: "Crunches", type: ["Abs"])
        let sitUps = Workout(imageName: "sit-ups", name: "Sit-ups", type: ["Abs"])
        let sittingTwists = Workout(imageName: "sittingtwists", name: "Sitting Twists", type: ["Abs"])
        let jumpSquats = Workout(imageName: "jumpsquats", name: "Jump Squats", type: ["Cardio", "Butt"])
        let sideKicks = Workout(imageName: "sidekicks", name: "Side Kicks", type: ["Legs"])
        let climberTaps = Workout(imageName: "climbertaps", name: "Climber Taps", type: ["Cardio", "Abs"])
        let highKnees = Workout(imageName: "highknees", name: "High Knees", type: ["Cardio"])
        let plankHold = Workout(imageName: "plankhold", name: "Plank Hold", type: ["Abs"])
        let raisedArmCircles = Workout(imageName: "raisedarmcircles", name: "Raised Arm Cicles", type: ["Arms"])
        let pushUps = Workout(imageName: "push-ups", name: "Push-ups", type: ["Arms"])
        let elbowPlankHold = Workout(imageName: "elbowplankhold", name: "Elbow Plank Hold", type: ["Abs"])
        let kneeToElbowCrunches = Workout(imageName: "knee-to-elbowcrunches", name: "Knee-to-Elbow Crunches", type: ["Abs"])
        let sideLunge = Workout(imageName: "sidelunge", name: "Side Lunge", type: ["Legs"])
        let armScissors = Workout(imageName: "armscissors", name: "Arm Scissors", type: ["Arms"])
        let punches = Workout(imageName: "punches", name: "Punches", type: ["Arms"])
        let frontKicks = Workout(imageName: "frontkicks", name: "Front Kicks", type: ["Legs"])
        let sitUpPunches = Workout(imageName: "sit-uppunches", name: "Sit-up Punches", type: ["Abs", "Arms"])
        
        let abs = Filter(type: "Abs")
        let arms = Filter(type: "Arms")
        let legs = Filter(type: "Legs")
        let butt = Filter(type: "Butt")
        let cardio = Filter(type: "Cardio")
        
        workouts = [jumpingJacks, sideLegRaises, kneeToElbows, lungePunches, squatSideKick, squatFrontKick, legRaises, squatHold, marchSteps, calfRaises, lunges, shoulderTaps, plankRotations, highCrunches, sideJacks, bridges, hollowHold, crunches, sitUps, sittingTwists, jumpSquats, sideKicks, climberTaps, highKnees, plankHold, raisedArmCircles, pushUps, elbowPlankHold, kneeToElbowCrunches, sideLunge, armScissors, punches, frontKicks, sitUpPunches]
        
        ogWorkouts = [jumpingJacks, sideLegRaises, kneeToElbows, lungePunches, squatSideKick, squatFrontKick, legRaises, squatHold, marchSteps, calfRaises, lunges, shoulderTaps, plankRotations, highCrunches, sideJacks, bridges, hollowHold, crunches, sitUps, sittingTwists, jumpSquats, sideKicks, climberTaps, highKnees, plankHold, raisedArmCircles, pushUps, elbowPlankHold, kneeToElbowCrunches, sideLunge, armScissors, punches, frontKicks, sitUpPunches]
        
        filters = [abs, arms, legs, butt, cardio]
        
        let filterLayout = UICollectionViewFlowLayout()
        filterLayout.scrollDirection = .horizontal
        filterLayout.minimumInteritemSpacing = Fpadding
        
        filterCollection = UICollectionView(frame: .zero, collectionViewLayout: filterLayout)
        filterCollection.translatesAutoresizingMaskIntoConstraints = false
        filterCollection.backgroundColor = UIColor(red: 1, green: 153/255, blue: 102/255, alpha: 0.20)
        filterCollection.layer.cornerRadius = 5.0
        filterCollection.clipsToBounds = true
        filterCollection.delegate = self
        filterCollection.dataSource = self
        filterCollection.alwaysBounceHorizontal = true
        filterCollection.register(FilterCollectionViewCell.self,  forCellWithReuseIdentifier: filterReuseIdentifier)
        filterCollection.allowsMultipleSelection = true
        view.addSubview(filterCollection)
        
        let workoutLayout = UICollectionViewFlowLayout()
        workoutLayout.scrollDirection = .vertical
        workoutLayout.minimumLineSpacing = Rpadding*2
        
        workoutCollection = UICollectionView(frame: .zero, collectionViewLayout: workoutLayout)
        workoutCollection.translatesAutoresizingMaskIntoConstraints = false
        workoutCollection.backgroundColor = .white
        workoutCollection.delegate = self
        workoutCollection.dataSource = self
        workoutCollection.register(WorkoutCollectionViewCell.self, forCellWithReuseIdentifier: workoutCellReuseIdentifier)
        view.addSubview(workoutCollection)
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Friends", style: .plain, target: self, action: #selector(friends))
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            filterCollection.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
            filterCollection.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5),
            filterCollection.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5),
            filterCollection.heightAnchor.constraint(equalToConstant: 50)
            ])
        
        NSLayoutConstraint.activate([
            workoutCollection.topAnchor.constraint(equalTo: filterCollection.bottomAnchor, constant: 15),
            workoutCollection.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: Rpadding),
            workoutCollection.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            workoutCollection.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -Rpadding)
            ])
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.workoutCollection {
            return workouts.count
        }
        else {
            return filters.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == self.workoutCollection {
            let cellA = workoutCollection.dequeueReusableCell(withReuseIdentifier: workoutCellReuseIdentifier, for: indexPath) as! WorkoutCollectionViewCell
            let workout = workouts[indexPath.item]
            cellA.configure(with: workout)
            cellA.setNeedsUpdateConstraints()
            return cellA
        }
        if collectionView == self.filterCollection {
            let cellB = filterCollection.dequeueReusableCell(withReuseIdentifier: filterReuseIdentifier, for: indexPath) as! FilterCollectionViewCell
            let filter = filters[indexPath.item]
            cellB.configure(with: filter)
            cellB.setNeedsUpdateConstraints()
            return cellB
        }
        return UICollectionViewCell()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if collectionView == self.workoutCollection {
            let width1 = (collectionView.frame.width - Rpadding * 2.0) / 2.0
            return CGSize(width: width1, height: width1)
        }
        if collectionView == self.filterCollection {
            let width2 = (collectionView.frame.width - Fpadding * 10.0) / 4.0
            return CGSize(width: width2, height: 30)
        }
        return CGSize(width: 0, height: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.workoutCollection {
            let workout = workouts[indexPath.item]
            let workoutViewController = WorkoutViewController()
            viewWorkoutDelegate = workoutViewController
            workoutViewController.workoutZoomDelegate = self
            let img = workout.imageName
            let name = workout.name
            let type = workout.type
            viewWorkoutDelegate?.workoutInfo(imageName: img!, name: name!, type: type!, index: indexPath.item)
            present(workoutViewController, animated: true, completion: nil)
        }
        else {
            let cellB = filterCollection.dequeueReusableCell(withReuseIdentifier: filterReuseIdentifier, for: indexPath)
            cellB.isSelected = !cellB.isSelected
            self.filtering()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        if collectionView == self.workoutCollection {}
        else {
            let cellB = filterCollection.dequeueReusableCell(withReuseIdentifier: filterReuseIdentifier, for: indexPath)
            cellB.isSelected = !cellB.isSelected
            self.filtering()
        }
    }
    
    func filtering() {
        workouts = ogWorkouts
        var filteredWorkouts: [Workout]! = []
        for cell in self.filterCollection!.visibleCells as! [FilterCollectionViewCell] {
            if cell.isSelected {
                let type = cell.filter.text!
                for w in workouts {
                    let tf = filteredWorkouts.contains(where: { $0.name == w.name })
                    for t in w.type {
                        if t == type && !tf {
                            filteredWorkouts.append(w)
                        }
                    }
                }
            }
        }
        if filteredWorkouts.count != 0 {
            workouts = filteredWorkouts
        }
        if filteredWorkouts.count == 0 {
            workouts = ogWorkouts
        }
        workoutCollection.reloadData()
    }
    
    @objc func friends() {
        let socialViewController = SocialViewController()
        navigationController?.pushViewController(socialViewController, animated: true)
    }

}

extension ViewController: WorkoutZoomDelegate {
    func seeWorkout(imageName: String, name: String, type: [String], index: Int) {
        let w = workouts[index]
        w.imageName =  imageName
        w.name = name
        w.type = type
        workoutCollection.reloadData()
    }
}
