//
//  PostViewController.swift
//  MusicFit
//
//  Created by Emily Reynolds on 11/29/18.
//  Copyright © 2018 Emily Reynolds. All rights reserved.
//
import UIKit

protocol PostField: class {
    func postField(workoutName: String, workoutImg: String)
}

class PostViewController: UIViewController {
    
    var viewLabel = UILabel()
    var nameLabel = UILabel()
    var nameField = UITextField()
    var workoutImage = UIImageView()
    var postLabel = UILabel()
    var postDescription = UITextField()
    var postButton: UIButton!
    
    weak var pushDelegate: PushField?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .white
        
        viewLabel.translatesAutoresizingMaskIntoConstraints = false
        viewLabel.backgroundColor = .white
        viewLabel.textAlignment = .center
        viewLabel.font = UIFont.boldSystemFont(ofSize: 24)
        viewLabel.text = "Create a post to share with friends!"
        view.addSubview(viewLabel)
        
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.backgroundColor = .white
        nameLabel.textAlignment = .left
        nameLabel.font = UIFont.systemFont(ofSize: 18)
        nameLabel.text = "Nickname:"
        view.addSubview(nameLabel)
        
        nameField.translatesAutoresizingMaskIntoConstraints = false
        nameField.backgroundColor = .white
        nameField.textAlignment = .left
        nameField.clearsOnBeginEditing = true
        nameField.borderStyle = .roundedRect
        view.addSubview(nameField)
        
        workoutImage.translatesAutoresizingMaskIntoConstraints = false
        workoutImage.contentMode = .scaleAspectFit
        view.addSubview(workoutImage)
        
        postLabel.translatesAutoresizingMaskIntoConstraints = false
        postLabel.backgroundColor = .white
        postLabel.textAlignment = .left
        postLabel.font = UIFont.systemFont(ofSize: 18)
        postLabel.text = "Write your post below:"
        view.addSubview(postLabel)
        
        postDescription.translatesAutoresizingMaskIntoConstraints = false
        postDescription.backgroundColor = .white
        postDescription.textAlignment = .left
        postDescription.clearsOnBeginEditing = true
        postDescription.borderStyle = .roundedRect
        view.addSubview(postDescription)
        
        postButton = UIButton()
        postButton.translatesAutoresizingMaskIntoConstraints = false
        postButton.setTitle("Share", for: .normal)
        postButton.backgroundColor = UIColor(red: 1, green: 153/255, blue: 102/255, alpha: 0.65)
        view.addSubview(postButton)
        
        postButton.addTarget(self, action: #selector(postToSocial), for: .touchUpInside)
        
        setupConstraints()
    }
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            viewLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            viewLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            viewLabel.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            workoutImage.topAnchor.constraint(equalTo: viewLabel.bottomAnchor, constant: 10),
            workoutImage.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            workoutImage.heightAnchor.constraint(equalToConstant: 260)
            ])
        
        NSLayoutConstraint.activate([
            nameLabel.topAnchor.constraint(equalTo: workoutImage.bottomAnchor, constant: 10),
            nameLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            nameLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            nameLabel.heightAnchor.constraint(equalToConstant: 20)
            ])
        
        NSLayoutConstraint.activate([
            nameField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 10),
            nameField.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            nameField.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            nameField.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            postLabel.topAnchor.constraint(equalTo: nameField.bottomAnchor, constant: 10),
            postLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            postLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            postLabel.heightAnchor.constraint(equalToConstant: 20)
            ])
        
        NSLayoutConstraint.activate([
            postDescription.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10),
            postDescription.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 10),
            postDescription.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            postDescription.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        NSLayoutConstraint.activate([
            postButton.topAnchor.constraint(equalTo: postDescription.bottomAnchor, constant: 30),
            postButton.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor),
            postButton.heightAnchor.constraint(equalToConstant: 30),
            postButton.widthAnchor.constraint(equalToConstant: 70)
            ])
        
    }
    
    @objc func postToSocial() {
        
    }
    
    @objc func workoutDescription() {
        navigationController?.popViewController(animated: true)
    }
    
    /*
     // MARK: - Navigation
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

extension PostViewController: PostField {
    func postField(workoutName: String, workoutImg: String) {
        viewLabel.text = workoutName
        workoutImage.image = UIImage(named: workoutImg)
    }
}
